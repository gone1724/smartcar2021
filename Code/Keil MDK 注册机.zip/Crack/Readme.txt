1. Install Keil MDK
2. Run Keil and copy from menu "File->License Management" Keil-ID of your computer
     from field "CID" (on first tab "Single-User License")
3. Run "KeilMDK5Keygen.exe" and copy Keil-ID of your coputer to field "CID"
4. Select Target "ARM"
5. Select edition of MDK "MDK Professional" (or whatever you need)
6. Generate key with "Generate" and copy it
7. In KeilMDK menu "File->License Management" copy key in field "New License ID Code"
     and apply it with "Add LIC"
     You can add several keys same way (steps 4-7) if you want
9. Work! :)
